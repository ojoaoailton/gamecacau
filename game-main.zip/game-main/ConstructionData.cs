using UnityEngine;

public class ConstructionData : MonoBehaviour
{
    public int id_construcao; // ID da construção no banco de dados
}
